How to use the minStack class:
	- Use minstack.push((INT)); to add a value to the stack, where (INT) is any integer.
	- Use minstack.pop((INT)); to return the top value, but delete it from the stack.
	- Use System.out.println(minstack.top()); to return the first item in the stack.
	- Use System.out.println(minstack.min()); to return the smallest value in the stack.

How to use the evalExpression class:
	- Use System.out.println(evalExpression(("EXPRESSION")); where ("EXPRESSION") is a string that fits
	  the following conditions:
		- Every term has a space before and after, except for the first and last respectively.
		- Surround the expression in qutoation marks.
		- Applicable expressions include... 
			- ("3 + 3 / 1 + 5 * 2")
			- ("6 * 2 / 2")
			- ("3 + 1 + 5 - 3")
How to use the postfix class:
	- Use System.out.println(postfix(("EXPRESSION")); where ("EXPRESSION") is a string that fits the following
	  conditions:
		- Every term has a space before and after, except for the first and last respectively.
		- Surround the expression in quotation marks.
		- Expression should be in postfix notation.
		- Applicable expressions include...
			- ("5 2 + 8 3 - * 4 /")
			- ("1 1 * 2 4 + 3 -)
	 