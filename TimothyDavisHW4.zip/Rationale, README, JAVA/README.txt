The following are instructions for using and running the program. 

To use deque . . . 
	- Change the number inside deque a = new deque(3); if desired. 
	- Change the numbers inside of a.insertLast(i) in any way desired.
	- Use a.printQueue() after any line to see how these changes are reflected in the queue
	- Use a.getRear, a.isFull, and a.deleteLast in any order or location within the question 1 section.
	- When you're ready, press run. 

To use merge . . .
	- Change the numbers withn ex1.add(i) if desired.
	- Add more numbers to the lists using ex1.add(i)/ex2.add(i) if desired.
	- When you're ready, press run. 

To use linkedQueue . . .
	- Change the numbers within q.enqueue(i) if desired.
	- Add more q.enqueue(i) if desired.
	- Change the numbers within q.dequeue(i) if desired.
	- Add more q.dequeue(i) if desired. 
	- use System.out.println(q.search(i)) to search for any integer in the list if desired.
	- use System.out.println(q.len()) to see the size of the list at any time. 


