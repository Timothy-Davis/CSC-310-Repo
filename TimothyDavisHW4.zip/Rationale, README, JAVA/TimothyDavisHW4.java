/*
 * Timothy Davis
 * CSC 310
 * Homework 4
 * 02-23-19
 */

package timothydavishw4;
import java.util.*;

class deque {
    // For deque, an array is a perfect data type to be a queue because we can
    // declare a max size, and access either back or front value easily in no more
    // than n-time.
    private int[] queue;
    private int index; 
    
    // Constructor that allows the user to set the max size at declaration.
    public deque(int i) {
        queue = new int[i];
    }
    
    // Checks to see if the array is empty by checking the index which is always
    // set to the index of the last value of the array
    public boolean isEmpty(){
        if(index == 0){
            return true;
        }
        
        return false;
    }
    
    // Checks to see if the array is full by checking to see if the index is equal
    // to the queue length, which is the max size of the array.
    public boolean isFull(){
        if(index == queue.length){
            return true;
        }
        
        return false;
    }
    
    // As long as the array is not full, insertFront will shift every value in the array
    // to the right, making the first value an empty [null] value. We then replace that 
    // [null] with the user's selected integer. Then it will increment index because
    // a number was added.
    public boolean insertFront(int k){
        if(this.isFull()){
            System.out.println("Cannot insert; queue is full!");
            return false;
        }
        
        for(int i = queue.length-1; i>0; i--){
            queue[i] = queue[i-1];
        }
        
        queue[0] = k;
        index++;
        return true;
    }
    
    // As long as the array is not full, insertLast will simply enter the user's 
    // selected integer at the index of the last value in the array. Then it will
    // increment index to reflect the added value. 
    public boolean insertLast(int k){
        if(this.isFull()){
            System.out.println("Cannot insert; queue is full!");
            return false;
        }
        
            queue[index] = k;
            index++;
            return true;
    }
    
    // As long as the array is not empty, deleteFront shifts the contents of the array
    // to the left, then sets the last value to 0, if the integer wrapped around.
    // The index is then decremented because a value was taken away.
    public boolean deleteFront(){
        if(this.isEmpty()){
            System.out.println("Cannot delete; queue is empty!");
            return false;
        }
        
        for(int i=0;i<index-1;i++){
            queue[i] = queue[i+1];
        }
        queue[queue.length-1] = 0;
        index--;
        return true;
    }
    
    // As long as the array is not empty, deleteLast simply sets the last value 
    // in the array to 0 and decrements index.
    public boolean deleteLast(){
        if(this.isEmpty()){
            System.out.println("Cannot delete; queue is empty!");
            return false;
        }
        
        index--;
        queue[index] = 0;
        return true;
    }
    
    // As long as the array is not empty, getFront will simply return the first
    // value in the array.
    public int getFront(){
        if(this.isEmpty()){
            System.out.println("Cannot return; queue is empty!");
            return -1;
        }
        
        return queue[0];
    }
    
    // As long as the array is not empty, getRear simply returns the very last
    // value in the array.
    public int getRear(){
        if(this.isEmpty()){
            System.out.println("Cannot return; queue is empty");
            return -1;
        }
        
        return queue[index-1];
    }
    
    // pirntQueue prints the queue for testing and display purposes.
    public void printQueue(){
        for(int i=0; i<index-1;i++){
            System.out.print(queue[i] + ", ");
        }
        System.out.println(queue[index-1]);
    }
}

class merge{
    private LinkedList<Integer> c = new LinkedList();
    
    // The following is a method that will take two sorted linked lists. 
    
    // As long as neither is empty, we will first check if either list is empty.
    // If so, we will add the values of the other list to the result linked list, c.
    // If not, we check if the first value of a is greater trhan b, if so, we add the smaller
    // of the two, and remove it from its list. We repeat this process until both lists
    // are empty.
    public LinkedList<Integer> merge(LinkedList<Integer> a, LinkedList<Integer> b){
        while(!(a.isEmpty()) || !(b.isEmpty())){
            if(b.isEmpty()){
                c.add(a.get(0));
                a.remove();
            } else if(a.isEmpty()){
                c.add(b.get(0));
                b.remove();
            } else {
                if(b.get(0) < a.get(0)){
                    c.add(b.get(0));
                    b.remove();
                } else {
                    c.add(a.get(0));
                    a.remove();
                }
            }
        } 
        return c;
    }
    
    // Print method for testing and display purposes
    public void print(){
        while(!(c.isEmpty())){
            System.out.print(c.get(0) + ", ");
            c.remove();
        }
        System.out.println("");
    }
}

class linkedQueue{
    LinkedList<Integer> queue = new LinkedList();
    
    // enqueue will add a value to the linked list. 
    public void enqueue(int x){
        queue.add(x);
    }
    
    // As long as the list is not empty, dequeue will Take the first value,
    // remove it from the list, and return it. If the list is empty, it will
    // return -9999999, notating an error. 
    public int dequeue(){
        if(queue.isEmpty()){
            System.out.println("Cannot dequeue; queue is empty!");
        } else {
            int a = queue.get(0);
            queue.remove();
            return a;
        }
        return -9999999;
    }
    
    // first will simply return the first value in the list. 
    public int first(){
        return queue.get(0);
    }
    
    // len will return the size of the list
    public int len(){
        return queue.size();
    }
    
    // is empty will return true if the list is empty, false otherwise
    public boolean isEmpty(){
        return queue.isEmpty();
    }
    
    // The following method will iterate through the list, looking for the user's
    // integer, if it is found, we return true, false otherwise.
    public boolean search(int x){
        boolean found = false;
        for (int i = 0; i < queue.size(); i++) {
            if(queue.get(i) == x){
                found = true;
            }
        }
        return found;
    }
    
}

public class TimothyDavisHW4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.print("Question 1 TESTING");
        System.out.println();
        deque a = new deque(3);
        System.out.println(a.insertLast(1));
        System.out.println(a.insertLast(2));
        System.out.println(a.insertFront(3));
        a.printQueue();
        a.insertFront(4);
        System.out.println(a.getRear());
        System.out.println(a.isFull());
        System.out.println(a.deleteLast());
        System.out.println(a.insertFront(4));
        a.printQueue();
        System.out.println(a.getFront());
        System.out.println();
        
        System.out.println("Question 2 TESTING");
        LinkedList<Integer> ex1 = new LinkedList();
        ex1.add(1);
        ex1.add(2);
        ex1.add(4);
        LinkedList<Integer> ex2 = new LinkedList();
        ex2.add(1);
        ex2.add(3);
        ex2.add(4);
        merge g = new merge();
        LinkedList<Integer> res = g.merge(ex1, ex2);
        g.print();
        System.out.println("");
        System.out.println();
        
        System.out.println("Question 3 TESTING");
        linkedQueue q = new linkedQueue();
        q.enqueue(2);
        q.enqueue(1);
        System.out.println(q.len());
        q.dequeue();
        System.out.println(q.len());
        q.enqueue(4);
        System.out.println(q.search(4));
        System.out.println(q.search(75));
        System.out.println(q.first());
        System.out.println(q.isEmpty());
    }
    
}
