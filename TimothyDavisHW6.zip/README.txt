Following are instructions on running each method in the program

Priority Queue - 
	- To run priority queue, use the proved int[] a, or change the values if you like, then run the program. It will return
	  sorted.

inPlaceHeapSort - 
	- To run inPlaceHeapSort, use the provided int[] b, or change the values if you like, then run the program. it will also
	  return a sorted array.

binaryMinHeap -
	- use binaryMinHeapExample.insert(integer) to insert values, then use binaryMinHeapExample.remove_min() to
	  return the lowest value provided thus far. Run the program.