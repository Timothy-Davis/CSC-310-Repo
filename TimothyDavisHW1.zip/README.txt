Below are instructions to run each methods:

Reverse_lines:
	- To run reverse_lines(), delete the hash mark that preceedes the call statement. 
	      # reverse_lines()      Should become      reverse_lines()
	- Run, then follow the instructions that appear on screen. 
	- After running reverse_lines(), delete the statement or put the hash back into the statement
		reverse_lines()      Should become    # reverse_lines()

Odd_Products:
	- To run odd_products(), delete the hash mark that preceedes the call statement.
	      # odd_products()       Should become      odd_products()
	- Run, then follow the instructions that appear on the screen.
	- After running odd_products(), delete the statement or put the hash back into the statment
		odd_products()       Should become    # odd_products()

Print_Permutations:
	- To run print_permutations(['1', '2', '3']), delete the hash mark that preceeds the call statement
	      # print_permutations(['1', '2', '3'])        Should become       print_permutations(['1', '2', '3'])
	- Then, you can replace the 1, 2, and 3 with your own values and run, or run as is. 
	- After running print_permutations(['1', '2', '3']), delete the statement or put the hash back into the statement.

Hemming_Dist:
	- To run hemming_dist(1, 4), delete the hash mark that preceeds the call statement
	      # hemming_dist(1, 4)   Should become    hemming_dist(1, 4)
	- Then, you can replace the 1, 4 with your own values and run, or run as is.
	- After running hemming_dist(1, 4), delete the statment or put the hash back into the statement. 