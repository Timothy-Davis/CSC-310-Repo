def reverse_lines():
    lines = []  # This array will store each line so that it's index can be used later in the algorithm
    done = False

    while not done:
        try:  # Use try/catch for error catching
            line = input('Enter lines of text to be reversed, press ctrl+z to finish: ')
            lines.append(line)  # Adds each line as an element of the lines array
        except EOFError:
            for i in range(len(lines) - 1, -1, -1):  # This loop prints from the last line to the first
                print(lines[i])
                done = True


def odd_product():
    num_array = []  # This int array will store the user's entered numbers
    done = False

    while not done:
        num = input('Enter numbers one per line, enter a blank line to indicate the end: ')

        if num == '':  # A blank line will break out of the while loop
            done = True
            break

        num_array.append(num)  # This statement adds the user's number to the num_array

    # The following nested loop will multiply every number in the num array together together,
    # if any product is odd, true is returned, and the loop is broken, otherwise, false is returned
    for i in range(0, len(num_array)-1):
        for j in range(0, len(num_array)-1):
            if (i*j) % 2 != 0:
                return True

    return False


def permutations(permList, l, r):#
    # This recursion will move the leftmost index to the right one at a time, so the base case returns the string
    # whenever this occurs.
    if l == r:
        print(permList)

    # The following loop runs len(permList) times, each time it locks one number in place at the beginning of the list
    # and swaps the numbers following it, creating len(permList)! distinct permutations.
    for i in range(l, r+1):  #
        t = permList[l]
        permList[l] = permList[i]
        permList[i] = t

        permutations(permList, l+1, r)

        t = permList[l]
        permList[l] = permList[i]
        permList[i] = t


# The following is a helper method that prevents the user from having to enter possibly confusing information
def print_permutations(string):
    permutations(string, 0, len(string)-1)


# dtb will convert the integer given by the user in hamming_dist to a binary number, making
# the hamming_distance calculation much easier within it's method
def dtb(x):
    binary = ''
    while x != 0:  # once x=0, the decimal to binary conversion is complete, as no integer division by 2 is possible.
        if x % 2 == 1:
            binary = '1'+binary
        elif x % 2 == 0:
            binary = '0'+binary
        x = x//2  # Use of integer division insures that we can take remainder, which is necessary for DtB conversion

    while len(binary) != 16:  # This while loop will insure that both binary strings are of equal (and max) length
        binary = '0' + binary

    return binary  # Returns the binary string for use in hamming_dist


def hamming_dist(x, y):
    cnt = 0
    x_binary = dtb(x)  # Uses the dtb method to convert the user's decimal number to a binary number
    y_binary = dtb(y)

    for x_char, y_char in zip(x_binary, y_binary):  # This loop compares each binary string character by character
        if x_char != y_char:
            cnt = cnt + 1

    return cnt  # cnt will be the hamming distance


# reverse_lines()
# print(odd_product())
print_permutations(['1', '2', '3'])
# print(hamming_dist(1, 4))
