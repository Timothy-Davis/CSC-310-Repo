Following are instructions on running each method in the program

Tower of Hanoi:
	- Once you run the program, a promt will appear, asking you how many disks you would like to have
	  on the initial tower, input any integer number you would like here, and the moves will be 
	  calculated.

preOrderTraversal and inOrderTraversal:
	- This method will take a binary tree (represented as an array), and the number 0 as input. 
	- To use your own array, you will need to make sure you have the root of the tree at index 0, and
	  that each left node is at index (2*(index of parent node) + 1) and each right node is at index
	  (2*(index of parent node) + 2).
	- If you wish to have empty nodes, they must be represented as 0s in the array.

		EX:            1
                              / \       Should be represnted in array form as int[] x = {1, 0, 2, 0, 0, 3, 0};
                                 2      Then called as preOrderTraversal(x, 0); or inOrderTraversal(x, 0); 
                                / \
                               3
		